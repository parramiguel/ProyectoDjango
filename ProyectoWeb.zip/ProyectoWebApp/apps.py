from django.apps import AppConfig


class ProyectowebappConfig(AppConfig):
    name = 'ProyectoWebApp'
