from django.apps import AppConfig


class ContactoConfig(AppConfig):
    name = 'contacto'
